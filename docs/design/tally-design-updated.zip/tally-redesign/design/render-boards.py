from pathlib import Path
import html
import subprocess
out=Path('tally-redesign/design')
A='#A69AEE';bg='#171719';panel='#202023';line='#343438';text='#ECECEF';muted='#A2A2AA'
def rect(x,y,w,h,fill,r=0,stroke=None):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}"'+(f' stroke="{stroke}"' if stroke else '')+'/>'
def ico(x,y,name,c=None,size=20):
 paths={'sun':'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1"/>','settings':'<path d="M4 6h5m4 0h7M4 12h10m4 0h2M4 18h3m4 0h9"/><circle cx="11" cy="6" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>','down':'<path d="m6 9 6 6 6-6"/>','edit':'<path d="m4 16 12-12 4 4L8 20H4v-4ZM13 7l4 4"/>','counter':'<circle cx="12" cy="12" r="8"/><path d="M12 8v8m-4-4h8"/>','history':'<path d="M4 6h16M4 12h16M4 18h16"/>','left':'<path d="m15 5-7 7 7 7"/>','right':'<path d="m9 5 7 7-7 7"/>','undo':'<path d="m8 5-4 4 4 4M4 9h10a5 5 0 0 1 0 10h-4"/>','close':'<path d="m6 6 12 12M6 18 18 6"/>','check':'<path d="m5 12 4 4L19 6"/>','plus':'<path d="M12 5v14M5 12h14"/>','export':'<path d="M12 16V3m-4 4 4-4 4 4M5 14v6h14v-6"/>','import':'<path d="M12 3v13m-4-4 4 4 4-4M5 16v4h14v-4"/>','trash':'<path d="M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/>','brand':'<path d="M5 4v16M10 4v16M15 4v16M20 4v16M2 17 22 7"/>'}
 return f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{c or muted}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+paths[name]+'</svg>'
def txt(x,y,t,size=14,fill=None,weight=400,anchor='start'):
 t=str(t);mapping={'☼':'sun','⚙':'settings','⌄':'down','✎':'edit','⊕':'counter','≡':'history','‹':'left','›':'right','×':'close','✓':'check','↗':'export','↓':'import'}
 if t in mapping:return ico(x-(size/2 if anchor=='middle' else size if anchor=='end' else 0),y-size+3,mapping[t],fill,size)
 extra=''
 if t.startswith('╱ tally.'):
  extra=ico(x,y-24,'brand',fill,24);x+=34;t='tally.'
 if t.startswith('↶  '):
  extra=ico(x-65,y-14,'undo',fill,16);t=t[3:];x+=9
 if t.startswith('+  '):
  extra=ico(x-67,y-15,'plus',fill,18);t=t[3:];x+=8
 if '  ›' in t:t=t.replace('  ›','');extra+=ico(x+3 if anchor!='end' else x+3,y-13,'right',fill,14);x-=5
 if t=='● ▰':return '<path d="M332 22h9m-9 3h9" stroke="'+muted+'" stroke-width="2"/>'+rect(347,17,16,9,'none',2,muted)+rect(349,19,10,5,muted,1)
 return extra+f'<text x="{x}" y="{y}" font-family="Inter, DejaVu Sans, sans-serif" font-size="{size}" fill="{fill or text}" font-weight="{weight}" text-anchor="{anchor}">{html.escape(t)}</text>'

def readable(c):
 rgb=[int(c[i:i+2],16)/255 for i in (1,3,5)]
 v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in rgb]
 lum=sum(x*k for x,k in zip(v,(.2126,.7152,.0722)))
 return '#000000' if (lum+.05)/.05 >= 1.05/(lum+.05) else '#FFFFFF'
def circ(x,y,r,c):return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}"/>'
def rule(y):return rect(22,y,346,1,line)
def base(history=False,light=False):
 global bg,panel,line,text,muted
 bg,panel,line,text,muted=('#F8F7FA','#FFFFFF','#DDDCE3','#27252D','#706B79') if light else ('#171719','#202023','#343438','#ECECEF','#A2A2AA')
 s=rect(0,0,390,844,bg,30)+txt(24,29,'9:41',13,weight=600)+txt(366,29,'● ▰',12,anchor='end')
 s+=txt(22,79,'╱ tally.',25,A,600)+txt(311,77,'☼',25,muted)+txt(353,77,'⚙',23,muted)
 s+=rect(22,101,297,52,panel,14,line)+circ(40,127,5,A)+txt(55,133,'Little moments',15,weight=500)+txt(295,132,'⌄',18,muted)+txt(345,133,'✎',24,muted)
 s+=rect(0,756,390,88,panel)+rect(0,756,390,1,line)
 for x,label,sel,glyph in [(100,'Counter',not history,'⊕'),(290,'History',history,'≡')]:
  if sel:s+=rect(x-30,765,60,30,'#343041' if not light else '#E6E1F7',15)
  s+=txt(x,790,glyph,24,A if sel else muted,anchor='middle')+txt(x,812,label,12,text if sel else muted,500,'middle')
 s+=rect(135,831,120,4,muted,2)
 return s

def heading(title,sub):return txt(22,194,title,26,weight=600)+txt(22,218,sub,13,muted)
def tabs(selected):
 s=rect(22,239,346,48,panel,12,line)
 for i,t in enumerate(['Days','Hours','Month']):
  if t==selected:s+=rect(26+i*114,243,110,40,'#35313F',9)
  s+=txt(81+i*114,269,t,14,text if t==selected else muted,500,'middle')
 return s

def pager(label):return txt(35,324,'‹',25,muted)+txt(163,322,label,14,weight=500,anchor='middle')+txt(284,324,'›',25,muted)+txt(345,322,'Today',12,A,500,'middle')+rule(340)

def counter(light=False):
 s=base(light=light)+heading('Make it count.','Monday, October 12')
 s+=circ(195,363,123,panel)+f'<circle cx="195" cy="363" r="123" fill="none" stroke="{line}"/>'+circ(195,363,110,A)
 s+=txt(195,381,'7',76,'#241F37',400,'middle')+txt(195,414,'TALLIES TODAY',11,'#241F37',500,'middle')
 action='#6D589F' if light else A
 s+=txt(195,514,'Tap to capture a moment',13,muted,anchor='middle')+rect(125,529,140,44,panel,22)+txt(195,557,'↶  Undo last tally',13,action,500,'middle')
 s+=rect(22,591,346,88,panel,14,line)
 for i,(label,num,unit) in enumerate([('Last 7 days','38','tallies'),('All time','148','moments'),('Streak','5','days')]):
  x=38+i*113;s+=txt(x,613,label,11,muted)+txt(x,640,num,24,weight=500)+txt(x,663,unit,11,muted)
 s+=txt(22,710,'Recent moments',14,weight=500)+txt(366,710,'View all  ›',12,action,anchor='end')+rule(723)+circ(29,741,4,A)+txt(43,745,'Today',12)+txt(367,745,'09:41',12,muted,anchor='end')
 return s

def days():
 s=base(True)+heading('History','148 recorded moments')+tabs('Days')+txt(22,317,'OCTOBER 2026',11,muted,500)+txt(366,317,'Preview data',11,A,anchor='end')
 for i,(d,day,n) in enumerate([(6,'Tuesday',3),(7,'Wednesday',0),(8,'Thursday',5),(9,'Friday',8),(10,'Saturday',6),(11,'Sunday',9),(12,'Monday',7)]):
  y=340+i*58;s+=rule(y)+txt(24,y+38,d,26,weight=400)+txt(75,y+24,day,14,weight=500)+txt(75,y+43,'October 2026'+(' · Today' if d==12 else ''),11,A if d==12 else muted)+txt(352,y+29,n,22,anchor='end')+txt(352,y+46,'tallies',10,muted,anchor='end')
 return s

def hours():
 s=base(True)+heading('History','7 tallies on this day')+tabs('Hours')+pager('Oct 12, 2026')
 s+=txt(22,365,'24-hour timeline',11,muted)+txt(366,365,'First tally: 07:12',11,muted,anchor='end')
 for i,h in enumerate(range(6,12)):
  y=390+i*56;s+=txt(22,y+5,f'{h:02}:00',11,muted)+rect(74,y,294,1,line)
 for h,m,x in [(7,12,98),(7,44,122),(8,18,98),(8,18,122),(9,4,98),(9,21,122),(9,41,146)]:
  y=390+(h-6)*56+m/60*56;s+=circ(x,y,6,A)
 s+=txt(22,746,'Tap a dot for its exact timestamp.',11,muted)
 return s

def month():
 s=base(True)+heading('History','63 tallies this month')+tabs('Month')+pager('October 2026')
 for i,t in enumerate(['M','T','W','T','F','S','S']):s+=txt(43+i*50,374,t,10,muted,anchor='middle')
 for d in range(1,32):
  i=d+2;x=22+i%7*50;y=391+i//7*52;n={1:7,2:4,3:1,4:8,5:5,6:3,7:0,8:5,9:8,10:6,11:9,12:7}.get(d,0)
  if n:
   import colorsys
   ratio=.12+n/9*.6
   c='#'+''.join(f'{round(a*(1-ratio)+b*ratio):02x}' for a,b in zip((32,32,35),(166,154,238)))
  else:c=panel
  s+=rect(x,y,46,48,c,9,A if d==12 else line)+txt(x+7,y+16,d,11)+txt(x+38,y+39,n if n else '',13,text,500,'end')
 s+=txt(22,681,'Less',11,muted)
 for i,c in enumerate(['#302D3D','#514968','#756BA0',A]):s+=rect(54+i*17,671,12,12,c,3)
 s+=txt(132,681,'More',11,muted)+txt(22,718,'Select any day to see its timeline.',12,muted)
 return s

def subjects():
 s=counter()+rect(0,0,390,756,'#00000088')+rect(0,286,390,470,panel,24)+rect(172,298,46,4,muted,2)
 s+=txt(24,345,'Your subjects',24,weight=600)+txt(24,371,'Keep each kind of moment separate.',13,muted)
 for i,(name,c,n) in enumerate([('Little moments',A,148),('Water','#7FB5A4',62),('Reading','#E3A77E',18)]):
  y=394+i*74;s+=rect(16,y,358,65,'#2C2838' if i==0 else panel,12)+circ(38,y+30,6,c)+txt(57,y+26,name,15,weight=500)+txt(57,y+46,f'{n} tallies',12,muted)
  if i==0:s+=txt(353,y+35,'✓',18,A,anchor='end')
 s+=rect(22,640,346,48,A,12)+txt(195,670,'+  New subject',14,'#241F37',600,'middle')+txt(195,725,'Swipe down to close',11,muted,anchor='middle')
 return s

def editor():
 s=base()+rect(0,0,390,756,'#00000088')+rect(0,224,390,532,panel,24)+rect(172,235,46,4,muted,2)
 s+=txt(24,281,'Edit subject',24,weight=600)+txt(355,279,'Cancel',14,muted,anchor='end')+txt(24,326,'Subject name',12,muted)+rect(24,340,342,52,bg,12,line)+txt(40,373,'Little moments',15)
 s+=txt(24,429,'Accent color',13,muted)
 for i,c in enumerate([A,'#7FB5A4','#E3A77E','#D58AAB','#82AEDD','#D2BD78']):
  s+=circ(44+i*60,463,16,c)
  if i==0:s+=f'<circle cx="44" cy="463" r="21" stroke="{text}" fill="none"/>'
 s+=txt(24,515,'Custom color',13,muted)+rect(24,529,342,48,bg,12,line)+circ(46,553,10,A)+txt(68,558,'#A69AEE',14)+txt(342,558,'RGB  ›',12,A,anchor='end')
 s+=txt(24,610,'Used for your counter, stamps and heatmap.',11,muted)+rect(24,646,342,48,A,12)+txt(195,676,'Save changes',14,'#241F37',600,'middle')+txt(195,725,'Delete subject',13,'#ED9898',anchor='middle')
 return s

def settings():
 s=base()+rect(0,92,390,664,bg)+txt(22,139,'‹',26,muted)+txt(52,139,'Settings & backup',23,weight=600)
 s+=txt(22,185,'APPEARANCE',11,muted,500)+rect(22,199,346,76,panel,14,line)+txt(38,228,'Theme',15)+txt(38,251,'Dark',12,muted)+txt(347,241,'Dark / Light',12,A,anchor='end')
 s+=txt(22,320,'YOUR DATA',11,muted,500)+rect(22,337,346,157,panel,14,line)+txt(38,369,'Export backup',15,weight=500)+txt(38,392,'All subjects, tallies and preferences',12,muted)+txt(349,376,'↗',20,A,anchor='end')+rect(38,414,314,1,line)+txt(38,449,'Restore backup',15,weight=500)+txt(38,472,'Choose a Tally JSON backup',12,muted)+txt(349,454,'↓',20,A,anchor='end')
 s+=txt(22,523,'Restore asks before replacing existing data.',11,muted)+txt(22,569,'EXPLORE',11,muted,500)+rect(22,584,346,68,panel,14,line)+txt(38,612,'Example preview',15)+txt(38,635,'Separate from your own moments',12,muted)+txt(350,619,'›',23,A,anchor='end')
 s+=txt(22,703,'Offline. No accounts or analytics.',12,muted)+txt(22,727,'Export a backup before uninstalling.',11,muted)
 return s

def delete_subject():
 s=subjects()+rect(0,0,390,844,'#00000099')+rect(24,270,342,294,panel,20,line)
 s+=ico(48,294,'trash','#ED9898',24)+txt(48,353,'Delete this subject?',22,weight=600)
 s+=txt(48,389,'Little moments and its 148 tallies',13,muted)+txt(48,410,'will be permanently deleted.',13,muted)+txt(48,445,'Your other subjects will stay intact.',12,muted)
 s+=rect(48,480,294,48,'#ED9898',12)+txt(195,510,'Delete subject and tallies',13,'#311616',600,'middle')+txt(195,548,'Cancel',14,anchor='middle')
 return s

def moment_detail():
 s=hours()+rect(0,0,390,756,'#00000088')+rect(0,438,390,318,panel,24)+rect(172,450,46,4,muted,2)
 s+=txt(24,492,'Recorded moment',23,weight=600)+txt(24,530,'Little moments',15)+txt(24,558,'Monday, October 12, 2026',13,muted)+txt(24,587,'09:41',27,weight=500)
 s+=rect(24,610,342,48,'#343041',12)+txt(195,640,'Done',14,A,500,'middle')+ico(111,692,'trash','#ED9898',18)+txt(212,706,'Delete tally',14,'#ED9898',500,'middle')
 return s

def delete_moment():
 s=moment_detail()+rect(0,0,390,844,'#00000099')+rect(24,280,342,263,panel,20,line)
 s+=txt(48,329,'Delete this tally?',22,weight=600)+txt(48,368,'Little moments · Oct 12, 09:41',13,muted)+txt(48,403,'Only this moment will be removed.',12,muted)
 s+=rect(48,435,294,48,'#ED9898',12)+txt(195,465,'Delete tally',14,'#311616',600,'middle')+txt(195,521,'Cancel',14,anchor='middle')
 return s

def empty_subjects():
 s=base()+rect(0,90,390,666,bg)+heading('A fresh start.','Create a subject to begin counting.')+ico(171,312,'counter',A,48)
 s+=txt(195,414,'No subjects yet',22,weight=500,anchor='middle')+txt(195,447,'Your next moment starts here.',13,muted,anchor='middle')+rect(40,488,310,48,A,12)+txt(195,518,'Create subject',14,'#241F37',600,'middle')
 s+=txt(195,566,'Or restore a backup in Settings.',12,muted,anchor='middle')
 return s


# Final usability revision: explicit controls, accessible calendar geometry, recovery states.
def base(history=False,light=False):
 global bg,panel,line,text,muted
 bg,panel,line,text,muted=('#F8F7FA','#FFFFFF','#DDDCE3','#27252D','#706B79') if light else ('#171719','#202023','#343438','#ECECEF','#A2A2AA')
 action='#6D589F' if light else A
 s=rect(0,0,390,844,bg,30)+txt(24,29,'9:41',13,weight=600)+txt(366,29,'● ▰',12,anchor='end')
 s+=txt(22,79,'╱ tally.',25,A,600)+rect(259,45,109,48,panel,12)+ico(270,59,'settings',muted,19)+txt(299,77,'Settings',13,muted)
 s+=rect(22,101,278,52,panel,14,line)+circ(40,127,5,A)+txt(55,133,'Little moments',15,weight=500)+ico(272,116,'down',muted,18)
 s+=rect(312,101,56,52,panel,12,line)+txt(340,133,'Edit',13,action,500,'middle')
 s+=rect(0,756,390,88,panel)+rect(0,756,390,1,line)
 for x,label,sel,glyph in [(100,'Counter',not history,'⊕'),(290,'History',history,'≡')]:
  if sel:s+=rect(x-30,765,60,30,'#343041' if not light else '#E6E1F7',15)
  s+=txt(x,790,glyph,24,action if sel else muted,anchor='middle')+txt(x,812,label,12,text if sel else muted,500,'middle')
 s+=rect(135,831,120,4,muted,2)
 return s

def pager(label):
 return rect(22,297,48,48,panel,10)+ico(36,311,'left',muted,20)+rect(76,297,181,48,panel,10)+txt(166,317,label,13,weight=500,anchor='middle')+txt(166,335,'Choose date',10,muted,anchor='middle')+rect(263,297,48,48,panel,10)+ico(277,311,'right',muted,20)+rect(317,297,51,48,panel,10)+txt(342,327,'Today',12,A,500,'middle')

def counter(light=False):
 s=base(light=light)+heading('Make it count.','Monday, October 12')
 s+=circ(195,363,123,panel)+f'<circle cx="195" cy="363" r="123" fill="none" stroke="{line}"/>'+circ(195,363,110,A)
 s+=txt(195,379,'7',76,'#241F37',400,'middle')+txt(195,414,'TALLIES TODAY',12,'#241F37',500,'middle')
 action='#6D589F' if light else A
 s+=ico(139,492,'plus',muted,18)+txt(209,507,'Tap to add',14,muted,anchor='middle')+rect(112,523,166,48,panel,24)+ico(125,538,'undo',action,18)+txt(209,553,'Undo last tally',13,action,500,'middle')
 s+=rect(22,589,346,80,panel,14,line)
 for i,(label,num,unit) in enumerate([('Last 7 days','38','tallies'),('All time','148','moments'),('Streak','5','days')]):
  x=38+i*113;s+=txt(x,609,label,12,muted)+txt(x,635,num,24,weight=500)+txt(x,656,unit,12,muted)
 s+=txt(22,695,'Recent moments',14,weight=500)+txt(362,695,'View all',13,action,anchor='end')+rule(704)+circ(29,730,4,A)+txt(43,735,'Today',13)+txt(347,735,'09:41',13,muted,anchor='end')+ico(352,720,'right',muted,16)
 return s

def days():
 s=base(True)+heading('History','148 recorded moments')+tabs('Days')+txt(22,321,'Earlier days are above today',12,muted)+rect(312,298,56,48,panel,10)+txt(340,328,'Today',12,A,500,'middle')
 for i,(d,day,n) in enumerate([(6,'Tuesday',3),(7,'Wednesday',0),(8,'Thursday',5),(9,'Friday',8),(10,'Saturday',6),(11,'Sunday',9),(12,'Monday',7)]):
  y=348+i*56;s+=rule(y)+txt(24,y+36,d,26)+txt(75,y+23,day,14,weight=500)+txt(75,y+42,'October 2026'+(' · Today' if d==12 else ''),12,A if d==12 else muted)+txt(338,y+25,n,22,anchor='end')+txt(338,y+43,'tallies',11,muted,anchor='end')+ico(350,y+17,'right',muted,16)
 return s

def hours():
 s=base(True)+heading('History','7 tallies on this day')+tabs('Hours')+pager('Oct 12, 2026')
 s+=txt(22,379,'Timeline · all 24 hours',12,muted)+rect(271,352,97,48,panel,10)+txt(319,382,'View list',13,A,500,'middle')
 for i,h in enumerate(range(6,11)):
  y=421+i*60;s+=txt(22,y+5,f'{h:02}:00',12,muted)+rect(74,y,294,1,line)
 for h,m,x in [(7,12,98),(7,44,154),(8,18,98),(8,18,154),(9,4,98),(9,21,154),(9,41,210)]:
  y=421+(h-6)*60+m;s+=circ(x,y,6,A)
 s+=txt(22,742,'Tap a dot for details. Scroll for more hours.',12,muted)
 return s

def month():
 s=base(True)+heading('History','63 tallies this month')+tabs('Month')+pager('October 2026')
 for i,t in enumerate(['M','T','W','T','F','S','S']):s+=txt(38+i*52,373,t,12,muted,anchor='middle')
 for d in range(1,32):
  i=d+2;x=14+i%7*52;y=390+i//7*54;n={1:7,2:4,3:1,4:8,5:5,6:3,7:0,8:5,9:8,10:6,11:9,12:7}.get(d,0)
  ratio=.12+n/9*.6
  c='#'+''.join(f'{round(a*(1-ratio)+b*ratio):02x}' for a,b in zip((32,32,35),(166,154,238))) if n else panel
  s+=rect(x,y,48,50,c,9,A if d==12 else line)+txt(x+7,y+17,d,12)+txt(x+40,y+41,n if n else '',14,readable(c),500,'end')
  if d==12:s+=rect(x+6,y+46,12,2,A,1)
 s+=txt(22,685,'Fewer',12,muted)
 for i,c in enumerate(['#302D3D','#514968','#756BA0',A]):s+=rect(61+i*17,674,12,12,c,3)
 s+=txt(136,685,'More',12,muted)+txt(22,720,'Select a day to see its tallies.',13,muted)
 return s

def subjects():
 s=counter()+rect(0,0,390,844,'#00000088')+rect(0,286,390,558,panel,24)+rect(172,298,46,4,muted,2)
 s+=txt(24,345,'Your subjects',24,weight=600)+txt(340,345,'Done',14,A,500,'middle')+txt(24,371,'Choose what you want to count.',13,muted)
 for i,(name,c,n) in enumerate([('Little moments',A,148),('Water','#7FB5A4',62),('Reading','#E3A77E',18)]):
  y=394+i*74;s+=rect(16,y,358,65,'#2C2838' if i==0 else panel,12)+circ(38,y+30,6,c)+txt(57,y+26,name,15,weight=500)+txt(57,y+46,f'{n} tallies',13,muted)
  if i==0:s+=ico(334,y+20,'check',A,20)
 s+=rect(22,662,346,48,A,12)+txt(195,692,'+  New subject',14,'#241F37',600,'middle')+txt(24,761,'Manage the selected subject with Edit.',12,muted)
 return s

def settings():
 s=base()+rect(0,90,390,666,bg)+ico(22,113,'left',muted,22)+txt(55,134,'Settings',24,weight=600)
 s+=txt(22,177,'Appearance',14,weight=500)+rect(22,193,346,52,panel,12,line)+rect(26,197,165,44,'#343041',10)+txt(108,225,'Dark',14,A,500,'middle')+txt(281,225,'Light',14,muted,500,'middle')
 s+=txt(22,286,'Backup',14,weight=500)+rect(22,302,346,148,panel,14,line)+txt(38,330,'Export backup',15,weight=500)+txt(38,352,'Save all subjects and tallies',13,muted)+ico(329,323,'export',A,21)+rect(38,373,314,1,line)+txt(38,404,'Restore backup',15,weight=500)+txt(38,426,'Choose a backup file',13,muted)+ico(329,396,'import',A,21)
 s+=txt(22,477,'Restore replaces your data after confirmation.',12,muted)+txt(22,523,'Example data',14,weight=500)+rect(22,539,346,72,panel,14,line)+txt(38,568,'Try example data',15,weight=500)+txt(38,591,'Your records stay separate',13,muted)+ico(335,562,'right',A,20)
 s+=txt(22,667,'Saved on this device · Works offline',13,muted)+txt(22,694,'Export a backup before uninstalling.',12,muted)
 return s

def timestamp_list():
 s=base(True)+heading('History','7 tallies on this day')+tabs('Hours')+pager('Oct 12, 2026')
 s+=txt(22,379,'Exact timestamps',13,muted)+rect(263,352,105,48,panel,10)+txt(315,382,'Timeline',13,A,500,'middle')
 for i,t in enumerate(['07:12','07:44','08:18','08:18','09:04','09:21','09:41']):
  y=410+i*48;s+=rule(y)+circ(31,y+24,5,A)+txt(49,y+29,t,15)+txt(295,y+28,'Details',12,muted)+ico(338,y+15,'right',muted,18)
 s+=txt(22,752,'',12,muted)
 return s

def date_jump():
 s=hours()+rect(0,0,390,844,'#00000088')+rect(12,215,366,470,panel,20,line)
 s+=txt(44,256,'Choose date',23,weight=600)+txt(44,285,'View tallies from any day.',13,muted)+txt(195,328,'October 2026',16,weight=500,anchor='middle')+ico(43,310,'left',muted,20)+ico(327,310,'right',muted,20)
 for i,t in enumerate(['M','T','W','T','F','S','S']):s+=txt(43+i*50,367,t,12,muted,anchor='middle')
 for d in range(1,32):
  i=d+2;x=20+i%7*50;y=383+i//7*48
  if d==12:s+=circ(x+23,y+17,18,A)
  s+=txt(x+23,y+22,d,13,'#211C35' if d==12 else text,anchor='middle')
 s+=txt(95,665,'Cancel',14,muted,anchor='middle')+txt(288,665,'Show day',14,A,500,'middle')
 return s

def feedback():
 s=counter()+rect(22,693,346,56,'#ECECEF',12)+txt(39,727,'Tally added · 09:41',14,'#27252D')+txt(340,727,'Undo',14,'#6D589F',600,'end')
 return s

def restore_confirmation():
 s=settings()+rect(0,0,390,844,'#00000099')+rect(22,247,346,360,panel,20,line)
 s+=txt(44,295,'Replace current data?',22,weight=600)+txt(44,333,'Backup: 3 subjects · 228 tallies',13,muted)+txt(44,363,'Your current subjects and tallies',13,muted)+txt(44,385,'will be replaced. This cannot be undone.',12,muted)
 s+=rect(44,409,302,48,bg,10,line)+txt(195,439,'Export current data first',13,A,500,'middle')+rect(44,471,302,48,'#ED9898',12)+txt(195,501,'Replace with backup',14,'#311616',600,'middle')+txt(195,557,'Cancel',14,anchor='middle')
 return s

def preview_state():
 s=counter()+rect(22,165,346,65,panel,12,line)+txt(37,191,'Example data',15,weight=500)+txt(37,215,'Your real records are separate',12,muted)+txt(342,202,'Exit preview',12,A,500,'end')
 s+=rect(22,491,346,82,bg)+txt(195,523,'Tallying is disabled in preview.',13,muted,anchor='middle')
 return s

def new_subject():
 s=editor()+rect(20,254,272,40,panel)+txt(24,281,'New subject',24,weight=600)+rect(25,341,340,50,bg,12,line)+txt(40,373,'e.g. Water or Reading',14,muted)
 s+=rect(24,646,342,48,'#343438',12)+txt(195,676,'Create subject',14,muted,500,'middle')+rect(22,701,346,49,panel)+txt(195,730,'Enter a name to continue.',12,muted,anchor='middle')
 return s

def custom_rgb():
 s=base()+rect(0,0,390,844,'#00000088')+rect(0,260,390,584,panel,24)+rect(172,272,46,4,muted,2)
 s+=txt(24,318,'Custom color',24,weight=600)+txt(351,316,'Cancel',14,muted,anchor='end')+txt(24,363,'Hex color',13,muted)+rect(24,377,342,52,bg,12,line)+txt(42,411,'#A69AEE',15)
 for i,(label,value) in enumerate([('Red',166),('Green',154),('Blue',238)]):
  y=465+i*69;s+=txt(24,y,label,13,muted)+rect(300,y-21,66,36,bg,8,line)+txt(333,y+3,value,14,anchor='middle')+rect(24,y+22,342,4,line,2)+rect(24,y+22,342*value/255,4,A,2)+circ(24+342*value/255,y+24,8,A)
 s+=rect(24,670,342,48,A,12)+txt(195,700,'Color preview',14,'#241F37',500,'middle')+rect(24,745,342,48,A,12)+txt(195,775,'Use this color',14,'#241F37',600,'middle')
 return s

def backup_error():
 s=settings()+rect(22,632,346,112,panel,14,'#ED9898')+txt(39,660,'Backup could not be opened',15,weight=500)+txt(39,685,'Your current data has not changed.',12,muted)+txt(39,722,'Choose another file',13,A,500)+txt(345,722,'Dismiss',13,muted,anchor='end')
 return s

def board(name,frames):
 w=860;h=950*((len(frames)+1)//2)+55
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'+rect(0,0,w,h,'#0D0D0F')+txt(25,34,'TALLY  /  PHONE DESIGN  /  FINAL',14,'#A2A2AA',500)
 for i,(title,fn) in enumerate(frames):
  x=25+i%2*420;y=70+i//2*950
  svg+=txt(x,y,title,15,'#ECECEF',500)+f'<g transform="translate({x},{y+20})">'+fn()+'</g>'
 svg+='</svg>';(out/(name+'.svg')).write_text(svg);subprocess.run(['node','-e',"require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp')(process.argv[1]).png().toFile(process.argv[2])",str(out/(name+'.svg')),str(out/(name+'.png'))],check=True)
board('core-screens',[('01  Counter',counter),('02  Days',days),('03  Hours',hours),('04  Month',month)])
board('supporting-screens',[('05  Subject switcher',subjects),('06  Subject editor',editor),('07  Settings',settings),('08  Light theme',lambda:counter(True))])

board('deletion-states',[('09  Delete subject',delete_subject),('10  Moment details',moment_detail),('11  Delete tally',delete_moment),('12  No subjects',empty_subjects)])

board('usability-states',[('13  Timestamp list',timestamp_list),('14  Choose date',date_jump),('15  Immediate feedback',feedback),('16  Restore confirmation',restore_confirmation)])

board('completion-states',[('17  Example mode',preview_state),('18  New subject',new_subject),('19  Custom RGB color',custom_rgb),('20  Backup error',backup_error)])
