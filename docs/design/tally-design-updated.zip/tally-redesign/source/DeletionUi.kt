package io.github.vontk.tally

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/** Presentation component. The caller must perform the confirmed database transaction. */
@Composable
fun DeleteSubjectConfirmation(
    name: String,
    tallyCount: Int,
    busy: Boolean = false,
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        icon = { MinimalTrashIcon() },
        title = { Text("Delete this subject?") },
        text = { Text("$name and its $tallyCount tallies will be permanently deleted. Your other subjects will stay intact.") },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = !busy) { Text("Delete subject and tallies") }
        },
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text("Cancel") } },
    )
}

@Composable
fun DeleteTallyConfirmation(
    subjectName: String,
    timestampLabel: String,
    busy: Boolean = false,
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        icon = { MinimalTrashIcon() },
        title = { Text("Delete this tally?") },
        text = { Text("$subjectName · $timestampLabel\nOnly this moment will be removed.") },
        confirmButton = { TextButton(onClick = onConfirm, enabled = !busy) { Text("Delete tally") } },
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text("Cancel") } },
    )
}

@Composable
private fun MinimalTrashIcon() {
    val tint = androidx.compose.material3.MaterialTheme.colorScheme.error
    Canvas(Modifier.size(20.dp).semantics { contentDescription = "Delete" }) {
        fun line(x: Float, y: Float, xx: Float, yy: Float) {
            drawLine(tint, Offset(size.width * x / 24, size.height * y / 24),
                Offset(size.width * xx / 24, size.height * yy / 24),
                strokeWidth = 1.7.dp.toPx(), cap = StrokeCap.Round)
        }
        line(4f, 6f, 20f, 6f)
        line(9f, 6f, 9f, 3f); line(9f, 3f, 15f, 3f); line(15f, 3f, 15f, 6f)
        line(6f, 6f, 7f, 21f); line(7f, 21f, 17f, 21f); line(17f, 21f, 18f, 6f)
        line(10f, 10f, 10f, 17f); line(14f, 10f, 14f, 17f)
    }
}
