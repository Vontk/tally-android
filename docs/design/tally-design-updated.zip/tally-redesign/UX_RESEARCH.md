# Final usability research and application

Reviewed 12 October 2026. This is a source-backed heuristic audit of the supplied Android design and successive revisions. It is not a user study, competitor benchmark, or proof of usability. General guidance informs the decisions; the specific layouts below are design judgments for Tally.

## Evidence and decisions

| Finding | Application to Tally | Primary source |
| --- | --- | --- |
| Icons frequently have ambiguous meanings; visible labels help interpretation. | Keep minimal line icons, but label Counter, History, Settings, Edit, Delete, and Undo. Replace the unexplained pencil and theme symbols with explicit controls. | Nielsen Norman Group, [Icon Usability](https://www.nngroup.com/articles/icon-usability/) |
| Recognizing visible options requires less recall than remembering hidden commands. | Keep Days / Hours / Month visible. Add a subject chevron, record-row chevrons and a visible View list action. No long-press-only deletion or swipe-only navigation. | NN/G, [Recognition and Recall](https://www.nngroup.com/articles/recognition-and-recall/) |
| Users need feedback about system state and completed actions. | Update today count immediately after accepted input; retain haptic/scale response and exact recent timestamp. Show progress and clear success/failure for backup operations. | NN/G, [Visibility of System Status](https://www.nngroup.com/articles/visibility-system-status/) |
| Native Compose controls should have touch regions of at least 48 dp; expanded regions can overlap. | Use distinct 48 dp controls for arrows, Today, Edit, Settings and color choices. Month tiles are 48 dp or larger at the illustrated phone width. Provide a list fallback for dense records and constrained layouts. | Android Developers, [Compose accessibility defaults](https://developer.android.com/develop/ui/compose/accessibility/api-defaults) |
| Do not communicate meaning through color alone; useful accessibility labels matter. | Subject names accompany dots, selected rows have a check, month cells include counts, Today has both a label/date reference and visual marker. Screen readers announce subject, date/time and count. | Android Developers, [Accessibility principles](https://developer.android.com/guide/topics/ui/accessibility/principles) |
| Normal text needs sufficient contrast; meaningful non-text indicators have their own contrast requirements. | Calculate label contrast separately from exact chosen subject color. Use black/white text on counter and heatmap fills; contrast-safe outlines for extreme-color stamps. Decorative dividers need not become visually heavy. | W3C, [Text contrast](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [Non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html) |
| Secondary choices can be disclosed after the primary task becomes clear. | Keep the main counter uncluttered. Put custom RGB controls beneath Custom color, data management in Settings, and subject creation in the subject switcher. | NN/G, [Progressive Disclosure](https://www.nngroup.com/articles/progressive-disclosure/) |
| Confirmation helps consequential actions, but routine confirmations become disruptive. | Never confirm adding a tally or using ordinary undo. Confirm irreversible subject deletion and restore; include subject name, record count and explicit action labels. Individual deletion remains confirmed until reliable undo is implemented. | NN/G, [Confirmation Dialogs](https://www.nngroup.com/articles/confirmation-dialog/) |
| Snackbars can provide brief, nonblocking operation feedback. | Feedback sits above bottom navigation, never covering the counter. Do not queue one popup per rapid tally; use the count as the main feedback and coalesce optional status. Backup and deletion results use concise status messages. | Android Developers, [Snackbar](https://developer.android.com/develop/ui/compose/components/snackbar) |
| Android supplies date picker components. | A visible Choose date control opens a native picker with calendar/input modes, avoiding dozens of repeated next/previous taps. Locale and device timezone remain respected. | Android Developers, [Date pickers](https://developer.android.com/develop/ui/compose/components/datepickers) |
| Save appropriate UI state to survive recreation and navigation. | Retain history view, date, scroll position, and per-subject context when switching tabs. Back dismisses the current overlay before leaving its parent screen. | Android Developers, [Saving UI state](https://developer.android.com/develop/ui/compose/state-saving), [Predictive Back](https://developer.android.com/develop/ui/compose/system/predictive-back-setup) |
| Errors should explain what happened and how to recover. | Invalid name/color errors appear beside the field. Invalid restore says data was unchanged and offers another file. Failed writes retain input and offer retry. Never show an unexplained error code. | NN/G, [Error-message guidelines](https://www.nngroup.com/articles/error-message-guidelines/) |
| Empty states can clarify purpose and offer a next action. | A new subject shows 0 and the add instruction; no subjects shows Create subject plus backup recovery. An empty day still presents the full timeline and a clear zero state. | NN/G, [Empty states](https://www.nngroup.com/articles/empty-state-interface-design/) |

These principles support the direction; none establishes that this exact screen arrangement has been empirically validated.

## Highest-priority audit fixes

1. **Ambiguous controls:** label Settings and Edit; retain labels on bottom destinations. Theme selection moves into a clearly labelled Appearance setting, preserving both modes.
2. **Accidental input:** keep the circle as the only add target. “Tap to add” is explanatory text, not a second button. Update the count per accepted tap and retain Undo last tally immediately underneath.
3. **Hidden history actions:** indicate that daily/calendar rows open details. Exact timestamp rows are fully tappable, eliminating dependence on tiny visible dots.
4. **Difficult date browsing:** add Choose date and Today. History remembers context; returning from detail restores the prior list position.
5. **Crowded timeline:** keep all 24 hours and exact-minute circles, but provide View list for dense hours and screen-reader use. When dot hit regions would overlap, offer a labelled hour-group target opening its timestamp list. Never force users to hit a 12 dp visual dot.
6. **Risky deletion:** put Delete subject below normal editor actions, with name/count confirmation. Expose individual deletion in timestamp details. Preview cannot modify real records.
7. **Calendar geometry:** preserve the rounded heatmap. On 390 dp designs the visible cells are at least 48 dp wide. Between 336 and 389 dp, reduce outer calendar gutters and inter-cell gaps first. Below 336 dp usable width or at high font scale, offer a labelled day list alternative; do not overlap hit targets to simulate compliance.
8. **Misleading precision:** retain numeric counts in every heatmap cell that contains records. Colors are relative to the displayed month; the legend describes fewer/more, not a universal intensity threshold.
9. **Data recovery:** restore confirmation states replacement scope and offers Export current data first. Busy/error/cancel states are specified rather than left to developers to invent.

## Behavior details

- **Add:** input is serialized; do not debounce away intentional rapid taps. Keep feedback aligned to committed data, reconcile failures, and never claim a failed write was saved.
- **Undo last tally:** removes the latest inserted record for the selected real subject, even after device clock changes. It is distinct from Undo in a deletion-result message.
- **Deletion recovery:** reliable restore of a deleted record is desirable, but must restore the original identity, timestamp and subject. Do not display an Undo action until the full storage layer supports it. The final design retains explicit confirmation for irreversible deletion.
- **Subject switch:** preserve the current destination, change its subject data, announce selection, and close the sheet. Reset selected record detail so records from a previous subject cannot be deleted accidentally.
- **Editor:** selected preset has a check/ring. Custom hex accepts six digits after #; RGB supports labelled sliders and direct numeric values in the full implementation. Validation explains the required format. Cancel closes; unsaved changes get a discard prompt if needed.
- **Back:** detail/dialog → dismiss; editor with changes → discard choice; date picker → cancel; Settings → previous destination. From a date drill-down, return to its originating history view before switching to Counter.
- **Preview:** persistent Example data badge with Exit preview. Real save, undo, delete and restore are unavailable in preview; export is explicitly described as exporting real data if offered.
- **Motion:** short, subtle response; obey reduced-motion/animation settings. Haptics supplement visuals and can be disabled through platform controls.

## What the design does not claim

The boards are illustrative vector mockups, not emulator captures. Measured default color pairs are checked in `design/contrast-checks.txt`; arbitrary custom colors must be evaluated at runtime. Focus order, TalkBack, font scaling, real storage errors and keyboard behavior require Android verification. This partial bundle does not contain the complete app project. Some final flows are specified and illustrated but not connected to the native ViewModel yet; see `DESIGN.md`.

## Release usability check

Use a task-based test with first-time users who have not seen these instructions. Do not guide them during the first attempt; ask what they expect before tapping unfamiliar controls.

| Task | Evidence to collect | Design acceptance goal |
| --- | --- | --- |
| Add a tally and undo it | First tap, mistaken taps, count comprehension | Main action found without help; one accepted tap = one record |
| Create Water, select its color, switch back | Wrong-subject entries, naming confusion | All controls discoverable; records stay isolated |
| Find an older day and inspect a timestamp | Backtracking, arrow repetition, missed dots | Date jump/list fallback discoverable; context retained |
| Delete one timestamp, then cancel subject deletion | Accidental bulk deletion, misunderstanding scope | Scope understood before confirmation |
| Delete the final subject | Dead ends | Create and restore remain available |
| Change theme and restore a backup | Confusion between export/restore, premature replacement | Correct operation chosen; replacement confirmed |
| Repeat with large font/TalkBack/narrow viewport | Truncation, overlap, focus traps | Every task remains possible; no hidden essential action |

These are proposed acceptance goals, not measured results. Log failures, adjust the design, and repeat the affected tasks before release.
